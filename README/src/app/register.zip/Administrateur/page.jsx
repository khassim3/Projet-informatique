"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { FaBars, FaTimes } from "react-icons/fa";
import Image from "next/image";
import Logo from "../../../public/Assets/logo-sansbg[1].svg";
import "../Administrateur/ad.css"; // Import du fichier CSS

const RolesPage = () => {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  // Liste des utilisateurs avec rôles
  const [users, setUsers] = useState([
    { id: 1, name: "Alice", role: "Étudiant" },
    { id: 2, name: "Bob", role: "Mentor" },
    { id: 3, name: "Charlie", role: "Étudiant" },
    { id: 4, name: "Diana", role: "Mentor" },
  ]);

  const [editingUserId, setEditingUserId] = useState(null);
  const [tempName, setTempName] = useState("");
  const [newUserName, setNewUserName] = useState("");
  const [newUserRole, setNewUserRole] = useState("Étudiant");

  // Changer le rôle d'un utilisateur
  const toggleRole = (id) => {
    setUsers((prevUsers) =>
      prevUsers.map((user) =>
        user.id === id ? { ...user, role: user.role === "Étudiant" ? "Mentor" : "Étudiant" } : user
      )
    );
  };

  // Commencer l'édition d'un nom
  const startEditing = (id, currentName) => {
    setEditingUserId(id);
    setTempName(currentName);
  };

  // Annuler la modification
  const cancelEditing = () => {
    setEditingUserId(null);
    setTempName("");
  };

  // Sauvegarder le nouveau nom
  const saveName = (id) => {
    setUsers((prevUsers) =>
      prevUsers.map((user) => (user.id === id ? { ...user, name: tempName } : user))
    );
    setEditingUserId(null);
  };

  // Ajouter un nouvel utilisateur
  const addUser = () => {
    if (newUserName.trim() === "") {
      alert("Le nom ne peut pas être vide.");
      return;
    }
    if (users.some((user) => user.name.toLowerCase() === newUserName.toLowerCase())) {
      alert("Ce nom existe déjà !");
      return;
    }
    const newUser = {
      id: Date.now(),
      name: newUserName,
      role: newUserRole,
    };
    setUsers((prevUsers) => [...prevUsers, newUser]);
    setNewUserName(""); // Réinitialiser le champ
  };

  return (
    <div className="mentore-container">
      {/* Navbar */}
      <nav className="navbar">
        <h2 className="logo">
          <Image src={Logo} alt="Logo" />
        </h2>

        {/* Menu responsive */}
        <div className="menu-icon" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <FaTimes size={30} /> : <FaBars size={30} />}
        </div>

        <div className={menuOpen ? "nav-links open" : "nav-links"}>
          <button onClick={() => router.push("/page.tsx")} className="nav-button">Accueil</button>
          <button onClick={() => router.push("/Statistique")} className="nav-button">Statistique</button>
          <button onClick={() => router.push("/Communication")} className="nav-button">Messages</button>
          <button onClick={() => router.push("/Utilisateur")} className="nav-button">Profil</button>
          <button onClick={() => router.push("/Historique")} className="nav-button">Historique</button>
          <button onClick={() => alert("Déconnexion...")} className="nav-button logout">Déconnexion</button>
        </div>
      </nav>

      {/* Gestion des Rôles */}
      <div className="roles-container">
        <h1 className="roles-title">Gestion des Rôles</h1>

        {/* Formulaire d'ajout d'utilisateur */}
        <div className="add-user-container">
          <input
            type="text"
            placeholder="Nom de l'utilisateur"
            value={newUserName}
            onChange={(e) => setNewUserName(e.target.value)}
            className="input-field"
          />
          <select
            value={newUserRole}
            onChange={(e) => setNewUserRole(e.target.value)}
            className="select-field"
          >
            <option value="Étudiant">Étudiant</option>
            <option value="Mentor">Mentor</option>
          </select>
          <button onClick={addUser} className="add-button">Ajouter</button>
        </div>

        {/* Tableau des utilisateurs */}
        <div className="roles-card">
          <table className="roles-table">
            <thead>
              <tr>
                <th>Nom</th>
                <th>Rôle</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>
                    {editingUserId === user.id ? (
                      <div className="edit-container">
                        <input
                          type="text"
                          value={tempName}
                          onChange={(e) => setTempName(e.target.value)}
                          className="edit-input"
                        />
                        <button onClick={() => saveName(user.id)} className="save-button">✅</button>
                        <button onClick={cancelEditing} className="cancel-button">❌</button>
                      </div>
                    ) : (
                      <span>{user.name}</span>
                    )}
                  </td>
                  <td className={user.role === "Mentor" ? "mentor-role" : "student-role"}>
                    {user.role}
                  </td>
                  <td>
                    <button onClick={() => toggleRole(user.id)} className="roles-button">Changer Rôle</button>
                    {editingUserId !== user.id && (
                      <button onClick={() => startEditing(user.id, user.name)} className="edit-button">Modifier Nom</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RolesPage;
