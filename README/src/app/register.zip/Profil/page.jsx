"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { FaBars, FaTimes } from "react-icons/fa"; // Icônes pour le menu
import "../Profil/profil.css";
import Image from "next/image";
import Logo from "../../../public/Assets/logo-sansbg[1].svg";

const MentorPage = () => {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  // Liste des mentorés
  const [mentores, setMentores] = useState([
    { id: 1, name: "Alice Dupont" },
    { id: 2, name: "Thomas Martin" },
    { id: 3, name: "Sophie Leroy" },
    { id: 4, name: "Lucas Bernard" },
  ]);

  return (
    <div className="mentore-container">
      {/* Navbar */}
      <nav className="navbar">
        <h2 className="logo">
          <Image src={Logo} alt="Logo" />
        </h2>

        {/* Menu responsive */}
        <div className="menu-icon" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <FaTimes size={30} /> : <FaBars size={30} />}
        </div>

        <div className={menuOpen ? "nav-links open" : "nav-links"}>
          <button onClick={() => router.push("")} className="nav-button">Accueil</button>
          <button onClick={() => router.push("/mentors")} className="nav-button">Mentors</button>
          <button onClick={() => router.push("/Communication")} className="nav-button">Messages</button>
          <button onClick={() => router.push("/Utilisateur")} className="nav-button">Profil</button>
          <button onClick={() => alert("Déconnexion...")} className="nav-button logout">Déconnexion</button>
        </div>
      </nav>

      {/* Contenu principal */}
      <div className="content">
        <h1>Liste des Cours</h1>
        <ul className="mentore-list">
          {mentores.map((mentore) => (
            <li key={mentore.id} className="mentore-item">
              {mentore.name}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default MentorPage;
