// app/login/page.jsx
"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import "../CSS/r.css";

const Login = () => {
  const router = useRouter();

  const goToProfil = () => {
    router.push('/Profil'); // Navigate to the register page
  };


  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Attempt to sign in with credentials
    const result = await signIn("credentials", {
      redirect: false, // Avoid automatic redirection
      email: formData.email,
      password: formData.password,
    });

    if (result?.error) {
      alert("Erreur de connexion : " + result.error);
    } else {
      alert("Connexion réussie !");
      router.push("./Profil"); // Redirect to the profile page
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Veuillez entrer vos identifiants</h2>
      <form onSubmit={handleSubmit} style={{ display: "inline-block", textAlign: "left" }}>
        <div style={{ marginBottom: "20px" }}>
          <label>
            Email :
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              style={{
                display: "block",
                marginTop: "5px",
                padding: "8px",
                width: "100%",
                maxWidth: "300px",
              }}
            />
          </label>
        </div>
        <div style={{ marginBottom: "20px" }}>
          <label>
            Mot de passe :
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              style={{
                display: "block",
                marginTop: "5px",
                padding: "8px",
                width: "100%",
                maxWidth: "300px",
              }}
            />
          </label>
        </div>
        <button onClick={goToProfil}
          type="submit"
          style={{
            padding: "10px 20px",
            backgroundColor: "green",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        > 
          Connexion
        </button>
      </form>
    </div>
  );
};

export default Login;
