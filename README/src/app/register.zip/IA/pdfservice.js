"use client";
import { jsPDF } from "jspdf";
import "../IA/ia.css";

// Fonction pour générer un PDF
export function generatePDF(plan, filename = "plan_apprentissage.pdf") {
  const doc = new jsPDF();

  // Ajouter un titre
  doc.setFontSize(18);
  doc.text("Plan d'apprentissage", 10, 10);

  // Ajouter le contenu du plan
  doc.setFontSize(12);
  const marginLeft = 10;
  const marginTop = 20;
  const lineHeight = 8;

  const lines = doc.splitTextToSize(plan, 190); // Gérer le retour à la ligne automatique
  let cursorY = marginTop;

  lines.forEach((line) => {
    doc.text(line, marginLeft, cursorY);
    cursorY += lineHeight;

    // Gérer le débordement de page
    if (cursorY > 280) {
      doc.addPage();
      cursorY = marginTop;
    }
  });

  // Télécharger le fichier PDF
  doc.save(filename);
}