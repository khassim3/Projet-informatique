"use client";
import { useState } from "react";
import { callMistralAI } from "../IA/mistral";
import { generatePDF } from "../IA/pdfservice";
import "../IA/ia.css";

const Page = () => {
  const [subject, setSubject] = useState("");
  const [duration, setDuration] = useState("");
  const [level, setLevel] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!subject || !duration || !level) return;
    setLoading(true);
    try {
      const result = await callMistralAI(subject, duration, level);
      setResponse(result);
    } catch (error) {
      console.error("Erreur lors de la requête API :", error);
    }
    setLoading(false);
  };

  return (
    <div className="container">
      <h1>Générateur de Plan d'Apprentissage</h1>
      <div className="input-group">
        <input
          type="text"
          placeholder="Sujet"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
        <input
          type="number"
          placeholder="Durée (semaines)"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
        />
        <input
          type="text"
          placeholder="Niveau"
          value={level}
          onChange={(e) => setLevel(e.target.value)}
        />
        <button onClick={handleSubmit} disabled={loading}>
          {loading ? "Chargement..." : "Générer le plan"}
        </button>
      </div>
      {response && (
        <div className="response">
          <h2>Plan d'Apprentissage</h2>
          <p>{response}</p>
          <button onClick={() => generatePDF(response)}>Télécharger en PDF</button>
        </div>
      )}
    </div>
  );
};

export default Page;
