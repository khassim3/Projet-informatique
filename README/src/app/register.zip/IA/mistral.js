"use client"
import axios from "axios";
import * as dotenv from "dotenv";
import "../IA/ia.css";

// Charger les variables d'environnement
//dotenv.config({ path: "fichier.env" });

// Configuration de l'API MistralAI
const mistralClient = axios.create({
  baseURL: "https://api.mistral.ai/v1", // URL de base
  headers: {
    Authorization: `Bearer 'Yk5jhx6DN9BXzkjufvKTWS1wdSglukJi'`,    
    // Utilise la clé API depuis .env
    "Content-Type": "application/json",
  },
});

// Fonction pour envoyer une requête à MistralAI
export async function callMistralAI(subject, duration, level) {
  const prompt = `Crée un plan structuré pour apprendre "${subject}". 
  Durée : ${duration} semaines. 
  Niveau : ${level}. 
  Décris chaque semaine avec des objectifs clairs et des ressources recommandées.`;

  try {
    const response = await mistralClient.post("/chat/completions", {
      model: "mistral-large-latest", // Modèle utilisé
      messages: [{ role: "user", content: prompt }], // Messages dynamiques
    });

    return response.data.choices[0].message.content; // Retourne uniquement le texte généré
  } catch (error) {
    console.error("Erreur lors de l'appel à MistralAI :", error.response?.data || error.message);
    throw error;
  }
}