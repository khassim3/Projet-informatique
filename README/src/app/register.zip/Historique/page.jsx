"use client";
import React, { useState } from "react";
import "../Historique/histo.css"; // Fichier CSS pour le style

const MentoratHistory = () => {
  // Liste simulée des sessions terminées
  const [sessions, setSessions] = useState([
    { id: 1, date: "2024-01-15", mentor: "Alice", student: "John", rating: 4 },
    { id: 2, date: "2024-01-18", mentor: "Bob", student: "Sarah", rating: 5 },
    { id: 3, date: "2024-01-20", mentor: "Charlie", student: "David", rating: 3 },
    { id: 4, date: "2024-01-25", mentor: "Diana", student: "Emma", rating: 5 },
  ]);

  // Génération du fichier CSV
  const downloadCSV = () => {
    const csvContent =
      "Date,Mentor,Étudiant,Évaluation\n" +
      sessions.map((session) => `${session.date},${session.mentor},${session.student},${session.rating}/5`).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Historique_Mentorat.csv";
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="history-container">
      <h2>Historique des Sessions de Mentorat</h2>

      <table className="history-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Mentor</th>
            <th>Étudiant</th>
            <th>Évaluation</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((session) => (
            <tr key={session.id}>
              <td>{session.date}</td>
              <td>{session.mentor}</td>
              <td>{session.student}</td>
              <td>
                {Array.from({ length: session.rating }).map((_, index) => (
                  <span key={index} className="star">⭐</span>
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button className="download-button" onClick={downloadCSV}>📥 Télécharger l’historique</button>
    </div>
  );
};

export default MentoratHistory;
