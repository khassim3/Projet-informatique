"use client";
import React, { useState } from "react";
import "../Utilisateur/utili.css"; // CSS pour le style

const Profile = () => {
  // Simuler les données de l'utilisateur
  const [user, setUser] = useState({
    lastName: "Doe",
    firstName: "John",
    email: "john.doe@example.com",
    password: "********",
    role: "Étudiant", // Ou "Mentor"
    coursesAsStudent: [
      { name: "Mathématiques", duration: "10 semaines", level: "Débutant" },
      { name: "Programmation Web", duration: "12 semaines", level: "Intermédiaire" },
    ],
    coursesAsMentor: [
      { name: "Algèbre Avancée", duration: "8 semaines", level: "Avancé" },
    ],
  });

  // État pour activer/désactiver l'édition
  const [isEditing, setIsEditing] = useState(false);

  // Gérer la modification des champs
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };

  // Sauvegarde des modifications
  const handleSave = () => {
    setIsEditing(false);
    alert("Profil mis à jour avec succès !");
  };

  return (
    <div className="profile-container">
      <h2>Profil de l'utilisateur</h2>
      
      <div className="user-info">
        <label>
          <strong>Nom:</strong>
          <input
            type="text"
            name="lastName"
            value={user.lastName}
            onChange={handleChange}
            disabled={!isEditing}
          />
        </label>

        <label>
          <strong>Prénom:</strong>
          <input
            type="text"
            name="firstName"
            value={user.firstName}
            onChange={handleChange}
            disabled={!isEditing}
          />
        </label>

        <label>
          <strong>Email:</strong>
          <input
            type="email"
            name="email"
            value={user.email}
            onChange={handleChange}
            disabled={!isEditing}
          />
        </label>

        <label>
          <strong>Mot de passe:</strong>
          <input
            type="password"
            name="password"
            value={user.password}
            onChange={handleChange}
            disabled={!isEditing}
          />
        </label>

        <label>
          <strong>Rôle:</strong> {user.role}
        </label>
      </div>

      {/* Boutons Modifier et Enregistrer */}
      {!isEditing ? (
        <button className="edit-button" onClick={() => setIsEditing(true)}>Modifier</button>
      ) : (
        <button className="save-button" onClick={handleSave}>Enregistrer</button>
      )}

      {/* Liste des cours */}
      <div className="courses">
        <h3>Cours suivis en tant qu'étudiant 📚</h3>
        {user.coursesAsStudent.length > 0 ? (
          <ul>
            {user.coursesAsStudent.map((course, index) => (
              <li key={index}>
                <strong>{course.name}</strong> - {course.duration} ({course.level})
              </li>
            ))}
          </ul>
        ) : (
          <p>Aucun cours suivi.</p>
        )}

        <h3>Cours enseignés en tant que mentor 👨‍🏫</h3>
        {user.coursesAsMentor.length > 0 ? (
          <ul>
            {user.coursesAsMentor.map((course, index) => (
              <li key={index}>
                <strong>{course.name}</strong> - {course.duration} ({course.level})
              </li>
            ))}
          </ul>
        ) : (
          <p>Vous ne donnez actuellement aucun cours.</p>
        )}
      </div>
    </div>
  );
};

export default Profile;
