
// pages/index.js
"use client"

import Image from "next/image";
import React from "react";
import Link from "next/link";

//import Navbar from "./Navbar/page"
//import Home from "./Home/page";
//import About from "./About/page";
//import Utilisateur from "./Utilisateur/page";
//import Profil from "./Profil/page";
import Supplementaire from "./Supplementaire/page";
//import Statistique from "./Statistique/page";
//import Historique from "./Historique/page";



function Index() {
  return (
    <div className="App">
      <Supplementaire/>
    </div> )
	}

export default Index;

